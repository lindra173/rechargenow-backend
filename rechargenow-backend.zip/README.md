# RechargeNow Backend

This is the backend for the RechargeNow app. It uses Express.js and LowDB for simplicity.

## How to run

1. Install dependencies:
```
npm install
```

2. Start the server:
```
node server.js
```
